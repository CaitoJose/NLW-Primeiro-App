HTML
- Hipertext
- Markup
 -- tags, elementos
- lenguage

CSS
 - Cascating style sheet

 JavaScript
 - Interpretada pelo browser
 - dinâmica
 -orientada a objeto
 -ECMAScript trazendo inovações

 Conceitos Fundamentais de programação
   -Comentários
   -Declaração de variáveis (const, let)
   -Operadores ( atribuição, concatenação)
   -Tipos de dados ( string, naumber, bolean, Date)
   -Estrutura de dados (function, objet, array)
   -Controle de fluxo (ij, else)
   -Estrutura de repetilção (for)
    -Manipulação e gestão de dados
      -Comversão de dados






// comentários, variáveis, tipos de dados, function,atribuicao de valor
//variaveis
//const mensagem = "Boa noite ou bom dia"

//tipo de dado
  //strings: '' , "" ``
    //number: 1, 2 , 3
     //function
//alert(mensagem)